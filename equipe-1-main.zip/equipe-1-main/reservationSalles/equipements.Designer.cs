
namespace reservationSalles2018
{
    partial class frmEquipements
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEquipements));
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbxPrixEquipement = new System.Windows.Forms.TextBox();
            this.tbxQuantiteEquipement = new System.Windows.Forms.TextBox();
            this.tbxNomEquipement = new System.Windows.Forms.TextBox();
            this.btnAjouterEquipement = new System.Windows.Forms.Button();
            this.btnEnregistrerEquipement = new System.Windows.Forms.Button();
            this.btnSupprimerEquipement = new System.Windows.Forms.Button();
            this.btnAnnulerEquipement = new System.Windows.Forms.Button();
            this.btnModifierEquipement = new System.Windows.Forms.Button();
            this.btnRechercherEquipement = new System.Windows.Forms.Button();
            this.tbxRechercherEquipement = new System.Windows.Forms.TextBox();
            this.lbxEquipements = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(456, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 20);
            this.label4.TabIndex = 88;
            this.label4.Text = "Prix location";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(456, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 20);
            this.label3.TabIndex = 87;
            this.label3.Text = "Quantité";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(456, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 20);
            this.label2.TabIndex = 86;
            this.label2.Text = "Nom";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(451, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(369, 33);
            this.label1.TabIndex = 85;
            this.label1.Text = "Gestion des équipements";
            // 
            // tbxPrixEquipement
            // 
            this.tbxPrixEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxPrixEquipement.Location = new System.Drawing.Point(589, 239);
            this.tbxPrixEquipement.Name = "tbxPrixEquipement";
            this.tbxPrixEquipement.Size = new System.Drawing.Size(241, 26);
            this.tbxPrixEquipement.TabIndex = 84;
            // 
            // tbxQuantiteEquipement
            // 
            this.tbxQuantiteEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxQuantiteEquipement.Location = new System.Drawing.Point(589, 183);
            this.tbxQuantiteEquipement.Name = "tbxQuantiteEquipement";
            this.tbxQuantiteEquipement.Size = new System.Drawing.Size(241, 26);
            this.tbxQuantiteEquipement.TabIndex = 83;
            // 
            // tbxNomEquipement
            // 
            this.tbxNomEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxNomEquipement.Location = new System.Drawing.Point(589, 127);
            this.tbxNomEquipement.Name = "tbxNomEquipement";
            this.tbxNomEquipement.Size = new System.Drawing.Size(241, 26);
            this.tbxNomEquipement.TabIndex = 82;
            // 
            // btnAjouterEquipement
            // 
            this.btnAjouterEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjouterEquipement.Location = new System.Drawing.Point(755, 347);
            this.btnAjouterEquipement.Name = "btnAjouterEquipement";
            this.btnAjouterEquipement.Size = new System.Drawing.Size(116, 42);
            this.btnAjouterEquipement.TabIndex = 81;
            this.btnAjouterEquipement.Text = "Ajouter";
            this.btnAjouterEquipement.UseVisualStyleBackColor = true;
            this.btnAjouterEquipement.Click += new System.EventHandler(this.btnAjouterEquipement_Click);
            // 
            // btnEnregistrerEquipement
            // 
            this.btnEnregistrerEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnregistrerEquipement.Location = new System.Drawing.Point(755, 347);
            this.btnEnregistrerEquipement.Name = "btnEnregistrerEquipement";
            this.btnEnregistrerEquipement.Size = new System.Drawing.Size(116, 42);
            this.btnEnregistrerEquipement.TabIndex = 80;
            this.btnEnregistrerEquipement.Text = "Enregistrer";
            this.btnEnregistrerEquipement.UseVisualStyleBackColor = true;
            this.btnEnregistrerEquipement.Click += new System.EventHandler(this.btnEnregistrerEquipement_Click);
            // 
            // btnSupprimerEquipement
            // 
            this.btnSupprimerEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupprimerEquipement.Location = new System.Drawing.Point(604, 347);
            this.btnSupprimerEquipement.Name = "btnSupprimerEquipement";
            this.btnSupprimerEquipement.Size = new System.Drawing.Size(116, 42);
            this.btnSupprimerEquipement.TabIndex = 79;
            this.btnSupprimerEquipement.Text = "Supprimer";
            this.btnSupprimerEquipement.UseVisualStyleBackColor = true;
            this.btnSupprimerEquipement.Click += new System.EventHandler(this.btnSupprimerEquipement_Click);
            // 
            // btnAnnulerEquipement
            // 
            this.btnAnnulerEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnnulerEquipement.Location = new System.Drawing.Point(604, 347);
            this.btnAnnulerEquipement.Name = "btnAnnulerEquipement";
            this.btnAnnulerEquipement.Size = new System.Drawing.Size(116, 42);
            this.btnAnnulerEquipement.TabIndex = 78;
            this.btnAnnulerEquipement.Text = "Annuler";
            this.btnAnnulerEquipement.UseVisualStyleBackColor = true;
            this.btnAnnulerEquipement.Click += new System.EventHandler(this.btnAnnulerEquipement_Click);
            // 
            // btnModifierEquipement
            // 
            this.btnModifierEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModifierEquipement.Location = new System.Drawing.Point(457, 347);
            this.btnModifierEquipement.Name = "btnModifierEquipement";
            this.btnModifierEquipement.Size = new System.Drawing.Size(116, 42);
            this.btnModifierEquipement.TabIndex = 77;
            this.btnModifierEquipement.Text = "Modifier";
            this.btnModifierEquipement.UseVisualStyleBackColor = true;
            this.btnModifierEquipement.Click += new System.EventHandler(this.btnModifierEquipement_Click);
            // 
            // btnRechercherEquipement
            // 
            this.btnRechercherEquipement.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRechercherEquipement.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRechercherEquipement.Image = ((System.Drawing.Image)(resources.GetObject("btnRechercherEquipement.Image")));
            this.btnRechercherEquipement.Location = new System.Drawing.Point(310, 40);
            this.btnRechercherEquipement.Name = "btnRechercherEquipement";
            this.btnRechercherEquipement.Size = new System.Drawing.Size(35, 38);
            this.btnRechercherEquipement.TabIndex = 76;
            this.btnRechercherEquipement.TabStop = false;
            this.btnRechercherEquipement.UseVisualStyleBackColor = true;
            // 
            // tbxRechercherEquipement
            // 
            this.tbxRechercherEquipement.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxRechercherEquipement.Location = new System.Drawing.Point(45, 45);
            this.tbxRechercherEquipement.Name = "tbxRechercherEquipement";
            this.tbxRechercherEquipement.Size = new System.Drawing.Size(244, 26);
            this.tbxRechercherEquipement.TabIndex = 75;
            // 
            // lbxEquipements
            // 
            this.lbxEquipements.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxEquipements.FormattingEnabled = true;
            this.lbxEquipements.ItemHeight = 20;
            this.lbxEquipements.Location = new System.Drawing.Point(45, 100);
            this.lbxEquipements.Name = "lbxEquipements";
            this.lbxEquipements.Size = new System.Drawing.Size(300, 304);
            this.lbxEquipements.TabIndex = 74;
            this.lbxEquipements.SelectedIndexChanged += new System.EventHandler(this.lbxEquipements_SelectedIndexChanged);
            // 
            // frmEquipements
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxPrixEquipement);
            this.Controls.Add(this.tbxQuantiteEquipement);
            this.Controls.Add(this.tbxNomEquipement);
            this.Controls.Add(this.btnAjouterEquipement);
            this.Controls.Add(this.btnEnregistrerEquipement);
            this.Controls.Add(this.btnSupprimerEquipement);
            this.Controls.Add(this.btnAnnulerEquipement);
            this.Controls.Add(this.btnModifierEquipement);
            this.Controls.Add(this.btnRechercherEquipement);
            this.Controls.Add(this.tbxRechercherEquipement);
            this.Controls.Add(this.lbxEquipements);
            this.Name = "frmEquipements";
            this.Text = "Equipements";
            this.Load += new System.EventHandler(this.frmEquipements_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxPrixEquipement;
        private System.Windows.Forms.TextBox tbxQuantiteEquipement;
        private System.Windows.Forms.TextBox tbxNomEquipement;
        private System.Windows.Forms.Button btnAjouterEquipement;
        private System.Windows.Forms.Button btnEnregistrerEquipement;
        private System.Windows.Forms.Button btnSupprimerEquipement;
        private System.Windows.Forms.Button btnAnnulerEquipement;
        private System.Windows.Forms.Button btnModifierEquipement;
        private System.Windows.Forms.Button btnRechercherEquipement;
        private System.Windows.Forms.TextBox tbxRechercherEquipement;
        private System.Windows.Forms.ListBox lbxEquipements;
    }
}