# AP 1.2 - Ticketing

Ce repository contient les fichiers et tickets nécessaires pour l'AP 1.2 - Ticketing

Vous trouverez les tickets dans l'onglet Issues
